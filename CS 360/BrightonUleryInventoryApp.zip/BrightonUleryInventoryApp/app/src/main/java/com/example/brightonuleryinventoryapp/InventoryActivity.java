package com.example.brightonuleryinventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Displays the inventory list and allows users to add/update/delete items.
 * Also handles SMS permission requests.
 */
public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.ItemCallbacks {
    private static final int LOW_STOCK_THRESHOLD = 5;
    private InventoryRepository inventory;
    private UserRepository users;
    private InventoryAdapter adapter;
    private String username;

    // Register the SMS permission launcher
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                Toast.makeText(this, granted ? "SMS permission granted." : "SMS permission denied.", Toast.LENGTH_SHORT).show();
            });

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_inventory);
        // Initialize the repositories and inventory adapter
        inventory = new InventoryRepository(this);
        users = new UserRepository(this);
        username = getIntent().getStringExtra("username");
        RecyclerView rvInventory = findViewById(R.id.rvInventory);
        rvInventory.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(this);
        rvInventory.setAdapter(adapter);
        refresh();
        // Bind UI elements
        TextInputEditText etName = findViewById(R.id.etAddName);
        TextInputEditText etQty = findViewById(R.id.etAddQty);
        TextInputEditText etSku = findViewById(R.id.etAddSku);
        MaterialButton btnAddItem = findViewById(R.id.btnAddItem);

        btnAddItem.setOnClickListener(v -> {
            String name = txt(etName), sku = txt(etSku);
            int qty;

            try {
                qty = Integer.parseInt(txt(etQty));
            } catch(Exception e) {
                qty = 0;
            }

            if(name.isEmpty()) {
                toast("Item name is required.");
                return;
            }

            long id = inventory.addItem(name, qty, sku);

            if(id != -1) {
                refresh();
                etName.setText("");
                etQty.setText("");
                etSku.setText("");
                checkSendLowStockAlert(name, qty);
            } else {
                toast("Failed to add item.");
            }
        });

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(this, SmsPermissionActivity.class));
        }
    }

    // Handles tapping an item to update quantity
    @Override
    public void onItemClicked(@NonNull InventoryRepository.Item item) {
        final TextInputEditText inputQty = new TextInputEditText(this);
        inputQty.setHint("New Quantity");
        inputQty.setText(String.valueOf(item.qty));

        new AlertDialog.Builder(this).setTitle("Update " + item.name).setView(inputQty).setPositiveButton("Save", (d, w) -> {
            int newQty;

            try {
                newQty = Integer.parseInt(txt(inputQty));
            } catch(Exception e) {
                newQty = item.qty;
            }

            if(inventory.updateItem(item.id, item.name, newQty, item.sku)) {
                refresh();
                checkSendLowStockAlert(item.name, newQty);
            }
        }).setNegativeButton("Cancel", null).show();
    }

    @Override
    public void onDeleteClicked(@NonNull InventoryRepository.Item item) {
        if(inventory.deleteItem(item.id)) {
            refresh();
        }
    }

    // Reloads RecyclerView contents
    private void refresh() {
        adapter.submitList(inventory.getAll());
    }

    // Triggers SMS permission if low-stock item added or updated.
    private void checkSendLowStockAlert(String name, int qty) {
        if(qty > LOW_STOCK_THRESHOLD) return;

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            toast("Low stock: " + name + " (" + qty + "). Add a phone number to receive SMS.");
            return;
        } else {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private static String txt(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
