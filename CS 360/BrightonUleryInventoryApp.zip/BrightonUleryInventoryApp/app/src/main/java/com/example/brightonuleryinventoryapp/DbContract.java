package com.example.brightonuleryinventoryapp;

import android.provider.BaseColumns;

/**
 * Defines the SQLite database tables.
 */
public class DbContract {
    private DbContract() {}

    // Table for user accounts
    public static final class UserEntry implements BaseColumns {
        public static final String TABLE = "users";
        public static final String COL_USERNAME = "username";
        public static final String COL_PASSWORD = "password";
    }

    // Table for inventory items
    public static final class ItemEntry implements BaseColumns {
        public static final String TABLE = "items";
        public static final String COL_NAME = "name";
        public static final String COL_QTY = "qty";
        public static final String COL_SKU = "sku";
    }
}
