package com.example.brightonuleryinventoryapp;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Screen for creating a new user account.
 * Validates inputs, enforces password confirmation, and writes the new user to the user table.
 */
public class CreateAccountActivity extends AppCompatActivity {
    private UserRepository users;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_create_account);
        users = new UserRepository(this);
        // Bind UI elements
        TextInputEditText etUsername = findViewById(R.id.etUsername);
        TextInputEditText etPassword = findViewById(R.id.etPassword);
        TextInputEditText etVerifyPassword = findViewById(R.id.etVerifyPassword);
        MaterialButton btnCreateAccount = findViewById(R.id.btnCreateAccount);

        btnCreateAccount.setOnClickListener(v -> {
            String u = txt(etUsername), p = txt(etPassword), vp = txt(etVerifyPassword);

            // Verify fields are not empty
            if(u.isEmpty() || p.isEmpty() || vp.isEmpty()) {
                toast("All fields required.");
                return;
            }

            // Verify passwords match
            if(!p.equals(vp)) {
                toast("Passwords do not match.");
                return;
            }

            boolean createUser = users.createUser(u, p);

            if(createUser) {
                toast("Account created. Please log in.");
                finish();
            } else {
                toast("Username already exists.");
            }
        });
    }

    private static String txt(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
