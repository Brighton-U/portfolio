package com.example.brightonuleryinventoryapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Manages database creation and updates.
 */
public class AppDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 2;

    public AppDbHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    /**
     * Called the first time the database is created. Creates tables defined in DbContract.
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + DbContract.UserEntry.TABLE + " (" +
                DbContract.UserEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                DbContract.UserEntry.COL_USERNAME + " TEXT UNIQUE NOT NULL," +
                DbContract.UserEntry.COL_PASSWORD + " TEXT NOT NULL)");
        db.execSQL("CREATE TABLE " + DbContract.ItemEntry.TABLE + " (" +
                DbContract.ItemEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                DbContract.ItemEntry.COL_NAME + " TEXT NOT NULL," +
                DbContract.ItemEntry.COL_QTY + " INTEGER NOT NULL DEFAULT 0," +
                DbContract.ItemEntry.COL_SKU + " TEXT)");
    }

    /**
     * Called when DB_VERSION is incremented. Drops and recreates all tables.
     * @param db The database.
     * @param oldV The old database version.
     * @param newV The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + DbContract.UserEntry.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + DbContract.ItemEntry.TABLE);
        onCreate(db);
    }
}
