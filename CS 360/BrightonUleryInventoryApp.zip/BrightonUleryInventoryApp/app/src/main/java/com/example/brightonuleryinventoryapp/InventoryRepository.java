package com.example.brightonuleryinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles item creation, updating, and deletion.
 */
public class InventoryRepository {
    public static class Item {
        public long id;
        public String name;
        public int qty;
        public String sku;

        public Item(long id, String name, int qty, String sku) {
            this.id = id;
            this.name = name;
            this.qty = qty;
            this.sku = sku;
        }
    }
    private final AppDbHelper helper;

    public InventoryRepository(Context ctx) {
        helper = new AppDbHelper(ctx);
    }

    public long addItem(String name, int qty, String sku) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbContract.ItemEntry.COL_NAME, name);
        cv.put(DbContract.ItemEntry.COL_QTY, qty);
        cv.put(DbContract.ItemEntry.COL_SKU, sku);
        return db.insert(DbContract.ItemEntry.TABLE, null, cv);
    }

    public boolean updateItem(long id, String name, int qty, String sku) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbContract.ItemEntry.COL_NAME, name);
        cv.put(DbContract.ItemEntry.COL_QTY, qty);
        cv.put(DbContract.ItemEntry.COL_SKU, sku);
        int rows = db.update(DbContract.ItemEntry.TABLE, cv, DbContract.ItemEntry._ID + "=?",
                new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean deleteItem(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        int rows = db.delete(DbContract.ItemEntry.TABLE, DbContract.ItemEntry._ID + "=?",
                new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public List<Item> getAll() {
        SQLiteDatabase db = helper.getReadableDatabase();
        List<Item> list = new ArrayList<>();

        try(Cursor c = db.query(DbContract.ItemEntry.TABLE,
                null, null, null, null, null,
                DbContract.ItemEntry.COL_NAME + " ASC")) {
            while(c.moveToNext()) {
                list.add(new Item(
                        c.getLong(c.getColumnIndexOrThrow(DbContract.ItemEntry._ID)),
                        c.getString(c.getColumnIndexOrThrow(DbContract.ItemEntry.COL_NAME)),
                        c.getInt(c.getColumnIndexOrThrow(DbContract.ItemEntry.COL_QTY)),
                        c.getString(c.getColumnIndexOrThrow(DbContract.ItemEntry.COL_SKU))
                ));
            }
        }

        return list;
    }
}
