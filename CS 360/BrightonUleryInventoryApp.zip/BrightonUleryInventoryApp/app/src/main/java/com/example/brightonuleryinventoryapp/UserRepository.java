package com.example.brightonuleryinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Handles user creation and login verification.
 */
public class UserRepository {
    private final AppDbHelper helper;

    public UserRepository(Context ctx) {
        helper = new AppDbHelper(ctx);
    }

    // Inserts a new user. Returns true if successful, false if the username already exists.
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbContract.UserEntry.COL_USERNAME, username);
        cv.put(DbContract.UserEntry.COL_PASSWORD, password);
        long id = db.insert(DbContract.UserEntry.TABLE, null, cv);
        return id != -1;
    }

    // Verifies the login by checking if the username/password pair exists in the user table.
    public boolean verifyLogin(String username, String password) {
        SQLiteDatabase db = helper.getReadableDatabase();

        try(Cursor c = db.query(DbContract.UserEntry.TABLE, new String[]{DbContract.UserEntry._ID},
                DbContract.UserEntry.COL_USERNAME + "=? AND " +
                        DbContract.UserEntry.COL_PASSWORD + "=?", new String[]{username, password},
                        null, null, null)) {
            return c.moveToFirst();
        }
    }
}
