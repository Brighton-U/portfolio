package com.example.brightonuleryinventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textview.MaterialTextView;

/**
 * RecyclerView adapter for inventory items.
 */
public class InventoryAdapter extends ListAdapter<InventoryRepository.Item, InventoryAdapter.VH> {
    // Callbacks for item clicks and deletions.
    interface ItemCallbacks {
        void onItemClicked(@NonNull InventoryRepository.Item item);
        void onDeleteClicked(@NonNull InventoryRepository.Item item);
    }

    static class VH extends RecyclerView.ViewHolder {
        MaterialTextView name, qty, sku;
        ImageButton delete;

        VH(@NonNull View v) {
            super(v);
            // Bind UI elements
            name = v.findViewById(R.id.tvItemName);
            qty = v.findViewById(R.id.tvItemQty);
            sku = v.findViewById(R.id.tvItemSku);
            delete = v.findViewById(R.id.btnDelete);
        }
    }

    private final ItemCallbacks callbacks;

    public InventoryAdapter(ItemCallbacks cb) {
        super(DIFF);
        this.callbacks = cb;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int viewType) {
        View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_inventory, p, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        InventoryRepository.Item item = getItem(pos);
        h.name.setText(item.name);
        h.qty.setText(String.valueOf(item.qty));
        h.sku.setText(item.sku == null ? "" : item.sku);
        h.itemView.setOnClickListener(v -> callbacks.onItemClicked(item));
        h.delete.setOnClickListener(v -> callbacks.onDeleteClicked(item));
    }

    private static final DiffUtil.ItemCallback<InventoryRepository.Item> DIFF = new DiffUtil.ItemCallback<InventoryRepository.Item>() {
        @Override
        public boolean areItemsTheSame(@NonNull InventoryRepository.Item oldItem, @NonNull InventoryRepository.Item newItem) {
            return oldItem.id == newItem.id;
        }

        @Override
        public boolean areContentsTheSame(@NonNull InventoryRepository.Item oldItem, @NonNull InventoryRepository.Item newItem) {
            return oldItem.name.equals(newItem.name) && oldItem.qty == newItem.qty && String.valueOf(oldItem.sku).equals(String.valueOf(newItem.sku));
        }
    };
}
