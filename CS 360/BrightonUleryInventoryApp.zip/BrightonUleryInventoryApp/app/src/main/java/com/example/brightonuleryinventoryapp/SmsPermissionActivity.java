package com.example.brightonuleryinventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;

/**
 * Screen for explaining and requesting SMS permissions.
 */
public class SmsPermissionActivity extends AppCompatActivity {
    private final ActivityResultLauncher<String> launcher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                Toast.makeText(this, granted ? "Permission granted." : "Permission denied.", Toast.LENGTH_SHORT).show();
                finish();
            });

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_sms_permission);
        // Bind UI elements
        MaterialButton btnAllowSms = findViewById(R.id.btnAllowSms);
        MaterialButton btnDenySms = findViewById(R.id.btnDenySms);

        // If permission granted, inform user, else request.
        btnAllowSms.setOnClickListener(v -> {
            if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission already granted.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                launcher.launch(Manifest.permission.SEND_SMS);
            }
        });

        btnDenySms.setOnClickListener(v -> {
            Toast.makeText(this, "SMS disabled. App will still work.", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
