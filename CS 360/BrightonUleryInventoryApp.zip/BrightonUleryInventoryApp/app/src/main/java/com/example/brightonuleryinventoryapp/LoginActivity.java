package com.example.brightonuleryinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Main launcher activity. Handles user login.
 */
public class LoginActivity extends AppCompatActivity {
    private UserRepository users;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_login);
        users = new UserRepository(this);
        // Bind UI elements
        TextInputEditText etUsername = findViewById(R.id.etUsername);
        TextInputEditText etPassword = findViewById(R.id.etPassword);
        MaterialButton btnLogin = findViewById(R.id.btnLogin);
        MaterialButton btnCreateAccount = findViewById(R.id.btnCreateAccount);

        // Attempt to log in
        btnLogin.setOnClickListener(v -> {
            String u = txt(etUsername), p = txt(etPassword);

            if(u.isEmpty() || p.isEmpty()) {
                toast("Enter username & password.");
                return;
            }

            if(users.verifyLogin(u, p)) {
                // Launch the inventory screen if login is successful
                Intent i = new Intent(this, InventoryActivity.class);
                i.putExtra("username", u);
                startActivity(i);
                finish();
            } else {
                toast("Invalid credentials or user not found.");
            }
        });

        // Go to the account creation screen
        btnCreateAccount.setOnClickListener(v ->
                startActivity(new Intent(this, CreateAccountActivity.class)));
    }

    private static String txt(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
