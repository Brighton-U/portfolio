from bson.objectid import ObjectId
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from typing import Any, Dict, List, Optional

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, user: str, password: str, host: str, port: int, db: str, col: str): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # Connection Variables 
        # 
        USER = user 
        PASS = password
        HOST = host
        PORT = port 
        DB = db
        COL = col
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 
    
    # Method for creating a document in the specified database and collection
    def create(self, data: Dict[str, Any]) -> bool:
        if not isinstance(data, dict) or not data:
            raise ValueError("Data must be a dictionary")
        try:
            result = self.collection.insert_one(data)
            return bool(result.acknowledged and result.inserted_id)
        except PyMongoError:
            return False

    # Method for reading a document in the specified database and collection
    def read(self, query: Dict[str, Any]) -> List[Dict[str, Any]]:
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary")
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError:
            return []
    
    # Method for updating a document in the specified database and collection
    def update(self, query: Dict[str, Any], data: Dict[str, Any]) -> int:
        if not isinstance(query, dict) or not query:
            raise ValueError("Query must be a dictionary")
        if not isinstance(data, dict) or not data:
            raise ValueError("Data must be a dictionary")
        try:
            result = self.collection.update_many(query, data)
            return int(result.modified_count)
        except PyMongoError:
            return 0
    
    # Method for deleting a document in the specified database and collection
    def delete(self, query: Dict[str, Any]) -> int:
        if not isinstance(query, dict) or not query:
            raise ValueError("Query must be a dictionary")
        try:
            result = self.collection.delete_many(query)
            return int(result.deleted_count)
        except PyMongoError:
            return 0